from bs4 import BeautifulSoup
import requests
import re, sys
import time
from functions import *
from selenium import webdriver
from selenium.webdriver.common.keys import Keys

if(len(sys.argv) > 1):
    x = sys.argv[1]
else: 
    x = str(input("ENTER URL: "))\

#x = str(input("ENTER URL: "))
print("Starting up Chrome Browser...")
driver = webdriver.Chrome()
driver.implicitly_wait(30)
#driver.maximize_window()
goto1 = "https://www.downloadnaija.com/dl2/login.php"
goto2 = "https://www.mp3downloadhits.com/dl2/login.php"
goto3 = "https://aprokomedia.com/mp3manager/indxxx.php"
goto4 = "https://www.naijaflavour.com/mp3manager/login.php"
driver.get(str(goto4))
name_box = driver.find_element("id","pin")
name_box.clear()
name_box.send_keys("90909")
sub = driver.find_element("xpath","//input[2]")
sub.click()

url = requests.get(x)
print("Opening: " + x)

soup = BeautifulSoup (url.text, features="lxml")
links = soup.select("div.archive-image > a")
print("Links selected")
i = 0
m = 14
n = 40
links = links[m:n]
for link in reversed(links):
    if(i==10 or i==20 or i==30 or i==40 or i==50 or i==60 or i==70 or i==80 or i==90 or i==100):
        time.sleep(10)
        print("I think i should rest so the server will not be mad at me...lol")
        print("Sleeping for 5 seconds..." + "\N{sleeping face}")
        
   
    link = link.get('href')
    
    req2 = req(link)
    #check1_mp3 = re.search(r"tory-lanez", link)
    check1_mp3 = 1
    if(check1_mp3 == 1):
        print("NO: ")
        print(i)
        print("\n")
        print("posting: " + link)
        print("\n")

        

        #category = cat(req2)
        #print(category)
        click2 = driver.find_element("id","1")
        click2.click()

        mp31 = mp3(req2)
        click3 = driver.find_element("name","url")
        click3.send_keys(str(mp31))


        title1 = title(req2)
        click4 = driver.find_element("name","name")
        click4.send_keys(str(title1))

        image1 = image(req2)
        imgcp = cpimg(image1, title1)
        click5 = driver.find_element("name","image")
        click5.send_keys(imgcp)
        if click5:

            body1 = body(req2, title1)
            click6 = driver.find_element("name","content")
            click6.send_keys(str(body1))

            category = cat(req2)
            click2 = driver.find_element("id",str(category))
            click2.click()
            
            click7 = driver.find_element("name","submit")
            click7.click()
            click8 = driver.find_element("xpath","/html/body/table/tbody/tr/td[1]/a/img")
            click8.click()
            i = i+1
            n = n-1
driver.close()
#exit()
x_filter = re.sub(r"https://www20.24naijamuzic.com/naija-songs/page/", "", x, flags=re.I)
x_filter = re.sub(r"/", "", x_filter, flags=re.I)
xx = int(x_filter) -1
if(xx >= 1):
    cmmd = "python3 scrappy.py https://www20.24naijamuzic.com/naija-songs/page/" + str(xx)
    os.system(cmmd)  
           

        
        
    

