from PyQt5 import QtCore, QtGui, QtWidgets
import Tor_rc
from PyQt5.QtWebEngineWidgets import *
from PyQt5.QtCore import *

class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        Mainwindow.setObjectName("MainWindow")
        Mainwindow.resize(800, 600)
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.Tor_label = QtWidgets.QLabel(self.centralwidget)
        self.Tor_label.setGeometry(QtCore.QRect(0, 0, 801, 551))
        self.Tor_label.setStyleSheet("background-image: url(:/newPrefix/tor.png);")
        self.Tor_label.setText("")
        self.Tor_label.setScaledContents(True)
        self.Tor_label.setObjectName("Tor_label")
        self.progressBar = QtWidgets.QProgressBar(self.centralwidget)
        self.progressBar.setGeometry(QtCore.QRect(350, 490, 118, 23))
        self.progressBar.setProperty("value", 24)
        self.progressBar.setObjectName("progressBar")
        self.searchButton = QtWidgets.QPushButton(self.centralwidget)
        self.searchButton.setGeometry(QtCore.QRect(310, 430, 201, 41))
        font = QtGui.QFont()
        font.setFamily("Algerian")
        font.setPointSize(18)
        font.setItalic(False)
        font.setUnderline(False)
        font.setStrikeOut(False)
        self.searchButton.setFont(font)
        self.searchButton.setMouseTracking(False)
        self.searchButton.setLocale(QtCore.QLocale(QtCore.QLocale.English, QtCore.QLocale.UnitedKingdom))
        self.searchButton.setAutoDefault(False)
        self.searchButton.setDefault(False)
        self.searchButton.setFlat(False)
        self.searchButton.setObjectName("searchButton")
        self.lineEdit = QtWidgets.QLineEdit(self.centralwidget)
        self.lineEdit.setGeometry(QtCore.QRect(210, 380, 401, 31))
        font = QtGui.QFont()
        font.setPointSize(12)
        self.lineEdit.setFont(font)
        self.lineEdit.setText("")
        self.lineEdit.setObjectName("lineEdit")
        self.label = QtWidgets.QLabel(self.centralwidget)
        self.label.setGeometry(QtCore.QRect(360, 320, 101, 31))
        font = QtGui.QFont()
        font.setPointSize(21)
        font.setItalic(False)
        self.label.setFont(font)
        self.label.setStyleSheet("background-color: rgb(255, 255, 255);")
        self.label.setObjectName("label")
        Mainwindow.setCentralWidget(self.centralwidget)
        self.menubar = QtWidgets.QMenuBar(MainWindow)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 800, 20))
        self.menubar.setObjectName("menubar")
        Mainwindow.setMenuBar(self.menubar)
        self.statusbar = QtWidgets.QStatusBar(MainWindow)
        self.statusbar.setObjectName("statusbar")
        Mainwindow.setStatusBar(self.statusbar)


        self.searchButton.clicked.connect(self.search)

        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

    def search(self):
        web=QWebEngineView()     
        url=str('http://www.'+self.lineEdit.text())
        web.load(QUrl(url))              
        web.show()

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        Mainwindow.setWindowTitle(_translate("MainWindow", "MainWindow"))
        self.searchButton.setText(_translate("MainWindow", "Search"))
        self.label.setText(_translate("MainWindow", "Browser"))




if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    MainWindow = QtWidgets.QMainWindow()
    ui = Ui_MainWindow()
    ui.setupUi(MainWindow)
    ui.search()
    Mainwindow.show()
    sys.exit(app.exec_())



