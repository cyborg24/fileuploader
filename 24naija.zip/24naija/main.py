#import selenium
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
import requests
from links import dowrk

print("Starting up Chrome Browser...")
driver = webdriver.Chrome()
driver.implicitly_wait(30)
driver.maximize_window()
driver.get("https://www.mp3downloadhits.com/dl2/login.php")
name_box = driver.find_element_by_id("pin")
name_box.clear()
name_box.send_keys("4747")
sub = driver.find_element_by_xpath("//input[2]")
sub.click()

while (1) :
    
    click2 = driver.find_element_by_id("1")
    click2.click()
    dowrk()
    click3 = driver.find_element_by_name("url")
    click3.send_keys(str(mp31))
    click4 = driver.find_element_by_name("name")
    click4.send_keys(str(title1))
    click5 = driver.find_element_by_name("content")
    click5.send_keys(str(body1))
    click6 = driver.find_element_by_class_name("logo")
    click6.click()