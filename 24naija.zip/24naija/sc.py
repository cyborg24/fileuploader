
from bs4 import BeautifulSoup
import re
import requests
import os
import wget

def cat():
    link = "https://www1.24naijamuzic.com/download-mp3/kizz-daniel-ft-wizkid-for-you/"
    site = requests.get(link).text
    soup = BeautifulSoup (site,  features="lxml")
    result = soup.select("#crumbs > a:nth-of-type(2)")
    
    for results in result:
        if(results.text == "Hip Hop"):
            return 9

    else:
        return 1

x = cat()
print(x)
