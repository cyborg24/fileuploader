from bs4 import BeautifulSoup
import re
import requests
import os
import wget
import wikipedia as wiki

def req(link):
    site = requests.get(link).text
    return site

def title(req2):
    
    soup = BeautifulSoup (req2,  features="lxml")
    result = soup.find_all('h1', class_='headline')
    for results in result:
        results = re.sub(r"MP3: ", "", results.text, flags=re.I)
        #print(results)
        print("\n")
        return results

def image(req2):
    
    soup = BeautifulSoup (req2,  features="lxml")
    result = soup.select("h3 > img") or soup.select("p > img") or soup.select("h3 > strong > img") or soup.select("div > img")
    #if(result[0] == "None"):
        #result = soup.select("p > img")
    
    for results in result:
        results = results.get('src')
        #print(results)
        return results

def body(req2, title1):
    
    soup = BeautifulSoup (req2,  features="lxml")
    result = soup.select("#content-area > p:nth-of-type(2)") or soup.select("#content-area > p:nth-of-type(3)") or soup.select("#content-area > p:nth-of-type(1)")or soup.select("#content-area > p")
    
    for results in result:
        #print(results.text)
        
        results = results.text

    print("\n\n Getting Article...\n")
    kw = re.split("–", title1)
                       
    #bold2 = "<strong>" + kw[1].strip() + "</strong>"
    kw = re.split("Ft.", kw[0])
    kw = re.split("&", kw[0])

    tag_link = kw[0].strip().lower()
    tag_link = tag_link.replace(" ", "-")

        
    bold1 = "<strong><a href='https://www.naijaflavour.com/tag/" + tag_link +"/'>" + kw[0].strip() + "</a></strong> "

    kwp = kw[0].strip() + " discography"
    try:
        res = wiki.summary(kwp, sentences = 10)
        results = res + "\n\n" + results
        results = results.replace(kw[0], bold1)
    except:
        results = results
        results = results.replace(kw[0], bold1)

    
    return results


def mp3(req2):
    
    soup = BeautifulSoup (req2,  features="lxml")
    result = soup.select("audio > a")
    
    for results in result:
        results = results.get('href')
        #print(results)
        return results

def cpimg(image1, title1):
    title1 = re.sub(r"/", "-", title1, flags=re.I)
    title1 = title1.replace("(", "_")
    title1 = title1.replace(")", "_")
    title1 = title1.replace("&", "-")
    url = image1
    os.system('rm -rf img')
    os.mkdir('img')
    print(url)
    #written = wget.download(url, out='img/')
    file = "wget " + image1 + " -O img/new.jpg"
    #written = os.system(file)
    #print(url)
    param = 'wget --user-agent="Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1)" -O img/' + title1 + '.jpg ' + url
    print(param)
    written = os.system(param)
    #written = wget.download(url, out='img/')

        #print("an error occoured")
	
    fn = os.listdir('img/')
    fm = 'img/' + fn[0]
    os.rename(fm, 'img/' + title1 + '-naijaflavour.jpg')
    fn = os.listdir('img/')
    #print(fn[0])
    ff = os.path.join('/home/cyborg/Desktop/Blog posters/24naija', 'img', fn[0])
    return ff
    #print(ff)


def cat(req2):
    
    soup = BeautifulSoup (req2,  features="lxml")
    result = soup.select("#crumbs > a:nth-of-type(2)")
    #print(result)
    for results in result:
        if(results.text == "Hip Hop" or None):
            return 111

        else:
            return 222
